#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__version__ = '0.1.26'
__date__ = 'Wed Apr 27 10:55:37 2022 +0200'
__commit__ = '2004d298f4276b106beb6b9095b731d385e6e8da'
def get_packages():
    return ['thorcam']
