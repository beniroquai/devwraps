#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__version__ = '0.1.25'
__date__ = 'Fri Apr 30 19:30:28 2021 +0100'
__commit__ = '53e1e37df7269fd899ad58945a88199ed2c30546'
def get_packages():
    return ['thorcam']
